package com.thinksys.parser.demo;

import java.io.IOException;
import java.nio.file.Path;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;

import com.google.protobuf.TextFormat.ParseException;

public class Searcher {

	IndexSearcher indexSearcher;
	Query query;
	QueryParser queryParser;
	final static Logger logger = Logger.getLogger(Searcher.class);
	

	public Searcher() {
		super();
	}

	public TopDocs search(Path luceneIndexDirectory, String searchQuery) throws IOException, ParseException, org.apache.lucene.queryparser.classic.ParseException{

		IndexReader reader = DirectoryReader.open(FSDirectory.open(Constants.LUCENE_INDEX_DIRECTORY));
		indexSearcher = new IndexSearcher(reader);
		queryParser = new QueryParser("text", new StandardAnalyzer());
		query = queryParser.parse(searchQuery);
		
		return indexSearcher.search(query,10);
	}

	public Document getDocument(ScoreDoc scoreDoc) 
			throws CorruptIndexException, IOException{
		return indexSearcher.doc(scoreDoc.doc);	
	}






//	public static void main (String []args) throws ParseException, IOException, org.apache.lucene.queryparser.classic.ParseException{
//
//		Searcher searcher = new Searcher();
//		long startTime = System.currentTimeMillis();
//		TopDocs hits = searcher.search(Constants.LUCENE_INDEX_DIRECTORY,"CANON");
//		long endTime = System.currentTimeMillis();
//
//		System.out.println(hits.totalHits +" documents found. Time :" + (endTime - startTime));
//		for(ScoreDoc scoreDoc : hits.scoreDocs) {
//			Document doc = searcher.getDocument(scoreDoc);
//			System.out.println("File: "+ doc.get("path"));
//		}
//
//	}

}
