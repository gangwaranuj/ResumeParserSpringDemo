package com.thinksys.parser.demo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;

public class Test {

	final static Logger logger = Logger.getLogger(Test.class);

	public static void main(String[] args) throws IOException, ParseException {

		try {

			/***********indexing*************/

			Indexer indexer=new Indexer();
			long startTime =System.currentTimeMillis();	
			int numIndexed =indexer.createIndex();
			long endTime = System.currentTimeMillis();
			System.out.println(numIndexed+" File indexed, Time taken: "+(endTime-startTime)+" ms");		
			indexer.indexWriter.close();
			System.out.println("Indexing Completed.");

			/**************indexing completed*****************/


			/***************input search keyword*********************/

			InputStreamReader r=new InputStreamReader(System.in);  
			BufferedReader br=new BufferedReader(r);  
			System.out.println("Enter your searchkeyword");  
			String searchquery=(br.readLine()).toLowerCase();


			/************************/

			/***************searcher*********************/

//			Term term1 = new Term("file", searchquery);
//			Query query1 = new TermQuery(term1);

			TopDocs hits;
			Searcher searcher = new Searcher();
			long searchstartTime  = System.currentTimeMillis();
			hits = searcher.search(Constants.LUCENE_INDEX_DIRECTORY,searchquery);






			long searchendTime = System.currentTimeMillis();
			System.out.println(hits.totalHits +" documents found. Time taken :" + (searchendTime - searchstartTime)+" ms");

			for(ScoreDoc scoreDoc : hits.scoreDocs) {
				Document doc = searcher.getDocument(scoreDoc);
				//System.out.println("File: "+ doc.get("path"));
				System.out.println("File name: "+ doc.get("file")+ ","+"  File Location :: " +doc.get("path"));
			}

			/**********************************************/

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
