package com.thinksys.parser.demo;

import java.nio.file.Path;
import java.nio.file.Paths;

public class Constants {

	public static final Path LUCENE_INDEX_DIRECTORY = Paths.get("D:/lucene/index");
	public static final String LUCENE_DOCUMENT_DIRECTORY = "D:/lucene/document/";
	public static final String DEVELOPER_FOLDER_DIRECTORY ="D:/lucene/ParseResume/";
	public static final String version="Version.LUCENE_6_0_1";
	
	
}
