package com.thinksys.parser.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.lucene.document.Document;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;

public class Test {

	private static Logger logger = Logger.getLogger(Test.class);

	public static void createNewDirectory(String directoryname){

		File file = new File(directoryname);
		if (!file.exists()) {
			if (file.mkdir()) {
				logger.info("Directory is created!");
			} else {
				logger.info("Failed to create directory!");
			}

		}
	}


	public static void main(String[] args) throws IOException, ParseException {

		try {

			/*********** indexing *************/

			Indexer indexer = new Indexer();
			indexer.createIndex();
			indexer.indexWriter.close();
			logger.info("Indexing Completed.");

			/************** indexing completed ****************/


			/*************** input search keyword *********************/
			InputStreamReader r = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(r);
			logger.info("Enter your searchkeyword");
			String skill = (br.readLine()).toLowerCase();
			/************************/



			/*************** searcher *********************/

			TopDocs hits;
			Searcher searcher = new Searcher();
			hits = searcher.search(Constants.LUCENE_INDEX_DIRECTORY, skill);

			if(hits.totalHits>0){

				String dirname=Constants.DEVELOPER_FOLDER_DIRECTORY+skill;
				createNewDirectory(dirname);
				for (ScoreDoc scoreDoc : hits.scoreDocs) {

					Document document = searcher.getDocument(scoreDoc);
					File sourceFile = new File(Constants.LUCENE_DOCUMENT_DIRECTORY+ document.get("file") );
					File destinationDir = new File(dirname+"/"+sourceFile.getName());
					FileUtils.copyFile(sourceFile, destinationDir);
					logger.info("File name: " + document.get("file") + "," + "  File Location :: " + document.get("path"));
				}
			}
			/**********************************************/
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("error: " + e);
		}
	}
}
